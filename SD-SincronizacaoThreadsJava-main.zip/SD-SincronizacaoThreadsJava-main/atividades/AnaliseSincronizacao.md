Sincronização de Threads em Java
